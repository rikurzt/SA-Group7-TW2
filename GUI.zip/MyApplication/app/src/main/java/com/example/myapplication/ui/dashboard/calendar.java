package com.example.myapplication.ui.dashboard;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class calendar extends AppCompatActivity {
    CalendarView calendarView;
    TextView myDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_dashboard);

        calendarView = findViewById(R.id.calendarView);
        myDate = findViewById(R.id.myDate);
        calendarView.setOnDateChangeListener((calendarView, i, i1, i2) -> {
            String date = (i1+1) +"/"+i2+"/"+i;
            myDate.setText(date);

        });
    }




}